//
//  TelrSDK.h
//  TelrSDK
//
//  Created by Kondya on 10/09/20.
//  Copyright © 2020 Fortune4. All rights reserved.
//

#import <Foundation/Foundation.h>

//! Project version number for TelrSDK.
FOUNDATION_EXPORT double TelrSDKVersionNumber;

//! Project version string for TelrSDK.
FOUNDATION_EXPORT const unsigned char TelrSDKVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <TelrSDK/PublicHeader.h>


